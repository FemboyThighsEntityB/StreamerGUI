﻿
namespace StreamerGui
{
    /// <summary>
    /// This class is used to provide information about your mod to BepInEx.
    /// </summary>
    class PluginInfo
    {
        // last time I had this under MILKSHAKE GT, because I didnt know if I wanted to release this or not
        public const string GUID = "com.Entity_B.StreamerGUI";
        public const string Name = "StreamerGU";
        public const string Version = "1.2";
    }
}
